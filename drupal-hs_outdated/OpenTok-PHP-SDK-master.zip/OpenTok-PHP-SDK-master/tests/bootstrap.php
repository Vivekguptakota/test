<?php

$loader = require __DIR__ . "/../vendor/autoload.php";
$loader->addPsr4('OpenTok\\', __DIR__.'/OpenTok');
/* vim: set ts=4 sw=4 tw=100 sts=4 et :*/
