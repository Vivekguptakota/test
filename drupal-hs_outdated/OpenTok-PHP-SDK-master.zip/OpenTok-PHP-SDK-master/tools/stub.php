<?php

Phar::mapPhar('opentok.phar');

require_once('phar://'.__FILE__.DIRECTORY_SEPARATOR.'vendor'.DIRECTORY_SEPARATOR.'autoload.php');

__HALT_COMPILER();
