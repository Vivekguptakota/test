# PHP

**[DEPRECATED]:** *This sample is here for historical purposes, a new one is being developed and this one will be removed when it is complete*

Zoom REST API's using PHP
Visit https://zoom.us/developer for more details
