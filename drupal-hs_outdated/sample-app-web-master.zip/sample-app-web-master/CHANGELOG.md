# CHANGELOG

## 2017-06-16

### Added

1. add success log and error log in init() and join()

2. add four parameters in init():
	disableInvite
	disableCallOut
	disableRecord
	disableJoinAudio
3. support to inviteCRCDevice and calcelInviteCRCDevice.

4. provide signature generate method


## 2017-04-28

### Added

1. support init web client, join meeting.

2. support to show/hide invite function.

3. support to show/hide meeting header.

4. support to get current attendees list.

5. support to call out to a phone.

6. support to recording a meeting.