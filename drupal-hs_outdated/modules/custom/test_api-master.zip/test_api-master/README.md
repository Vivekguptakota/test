# Custom RESTful API in Drupal 8

This is a very simple module that demonstrates implementation of a custom RESTful API in Drupal 8

The module example supports GET/POST/PUT/DELETE methods. The module doesn't have authentication.

Blog post: https://www.chapterthree.com/blog/custom-restful-api-drupal-8
